30-1-2025 
These files generate the figures in the introduction. They are all
jupyter notebooks incorporating the figures and they should contain
enough documentation to explain how to run them to generate the figs.

The've all been updated to run with the latest matplotlib.
Most of the figs are copied directly from the notebooks, but
for better resolution

Figure3_particle_version_show_particles_3_plots.ipynb
produces these three png files:

Figure3_1D_resampling_A.png
Figure3_1D_resampling_B.png
Figure3_1D_resampling_C.png

and
Figure4_particle_version.ipynb
produces these
Figure4_Hebb_particles_figA.png
Figure4_Hebb_particles_figB.png


