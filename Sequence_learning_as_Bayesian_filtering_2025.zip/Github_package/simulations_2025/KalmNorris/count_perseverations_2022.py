#!/Users/dennis/anaconda3/bin/python3


# !/imaging/local/software/anaconda/3_4.1.1/bin/python

'''
This only deals with hebb_9 lists on the last three repetitions (22, 25 and 28)
It prints out the positions where there is a protrusions and counts the number of trials where that is the case.

The trials look like this:



run_PF hebb_9
trial:  28
run_PF memoranda  ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']
run_PF gradient:  [9.000 8.000 7.000 6.000 5.000 4.000 3.000 2.000 1.000]
hebb_9 memoranda:    ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']
hebb_9 memoranda_by_index:  [0, 1, 2, 3, 4, 5, 6, 7, 8]
hebb_9 response by index:   [0, 1, 2, 5, 4, 3, 6, 7, 8]
error protrusion 3
error protrusion 5

All this does is pick up the 'error' line. The protrusions are picked up by PF in verbose mode


Would be useful to have a version that worked with all hebb lists


'''
import sys
gotone = False
all_sets = []
count = 0
max_pers = 0
count_num_perseverations_per_position = [0] * 11
new_count_num_perseverations_per_position = [0] * 11
new_count_lists_with_protrusions = 0
list_length = 9
end_of_iteration = False
penultimate = []  # holds trial 25
all_hebb_trials = []  # all of the hebb trials in an iteration
count_per_iteration = 0
iteration_number = 0


def check_triple_protrusions(hebbs_as_strings):
    #print('len hebbs_as_strings', len(hebbs_as_strings))
   # print(len(hebbs_as_strings[0]))
    hebbs_as_ints = []
    one_hebb_as_ints = []
    protrusions = [-1 for i in range(len(hebbs_as_strings[0]))]

    # first turn the messy string representations into integer arrays
    for trial in hebbs_as_strings:
        #print('trial', trial)
        for item in trial:
            tmp = item.replace('[', '')
            tmp = tmp.replace(']', '')
            tmp = tmp.replace(',', '')
            tmp = int(tmp)
            # tmp += 1   # and now count posns from 1
            #print('tmp', tmp)
            one_hebb_as_ints.append(tmp)
        hebbs_as_ints.append(one_hebb_as_ints)
        #print('hebbs_as_ints', hebbs_as_ints)
        one_hebb_as_ints = []
    #print('(hebbs_as_ints', hebbs_as_ints)

    last3 = hebbs_as_ints[-3:]  # last three hebbs only
    protrusions = [-1 for i in range(len(hebbs_as_strings[0]))]
    for count, h in enumerate(hebbs_as_ints):
        print(count + 1, end='. ')
        for i in h:
            print(i + 1, end=' ')
        print()

    print('\n')

    print('last3')
    for h in last3:
        for i in h:
            print(i + 1, end=' ')
        print()

    for h in last3:
        for count, item in enumerate(h):
            if item != count:  # item error
                #print('item error:', item, count, h, protrusions)
                # first error or error same as last protrusion
                # protrusions[count] holds the protrusions for posn
                if (protrusions[count] == -1) or item == protrusions[count]:
                    protrusions[count] = item
                    #print('found protrusion. count', count, 'item', item)
                else:
                    protrusions[count] = -2  # reset if the error is different
            else:
                protrusions[count] = -2  # reset if item correct

    for i in range(len(protrusions)):
        if protrusions[i] < 0:
            protrusions[i] = 0
        else:
            protrusions[i] += 1

    print('\n***************')
    print('protrusions:', protrusions)
    print('***************\n')

    p = []
    p_count = 0
    for i in protrusions:
        if i > 0:  # now we're counting from 1
            p.append(i)
            p_count += 1
    if p_count > 0:
        new_count_num_perseverations_per_position[p_count] += 1

    return p_count


print('prints instances where last two trials have same protrusions (i.e. last three have the same out-of-position items)')
for line in sys.stdin:
    x = line.split()
    all_sets.append(x)  # this holds each line as a list (odd naming)


for i in range(len(all_sets)):
    if len(all_sets[i]) > 1 and all_sets[i][1] == 'START':
      #  print('zaaaaaaaaa', all_sets[i])
        iteration_number += 1
        print('*******  iteration', iteration_number, ' ***********\n')
        all_hebb_trials = []
        count_per_iteration = 0
    if len(all_sets[i]) > 1 and all_sets[i][0] == 'trial:':
        trial = all_sets[i][1]
    if len(all_sets[i]) > 1 and all_sets[i][0] == 'hebb_9' and (all_sets[i][1] == 'memoranda_by_index:'):
        memoranda = ' '.join(all_sets[i][2:])
    if len(all_sets[i]) > 1 and all_sets[i][0] == 'hebb_9' and (all_sets[i][1] == 'response'):
        response = ' '.join(all_sets[i][4:])
        # keep a list of the resps for all Hebbs
        #        all_hebb_trials.append(response)
        all_hebb_trials.append(all_sets[i][4:])
    if len(all_sets[i]) > 1 and all_sets[i][1] == '30':
        end_of_iteration = True
        # this is now all that really matters:
        if check_triple_protrusions(all_hebb_trials) > 0:
            new_count_lists_with_protrusions += 1
        all_hebb_trials = []


print('count lists with three protrusions at end',
      new_count_lists_with_protrusions)
print('new_count_num_perseverations_per_position')
print('total:', sum(new_count_num_perseverations_per_position))
for i in range(list_length):
    print(i + 1,  new_count_num_perseverations_per_position[i])
