#!/usr/bin/env python
import random

hebb_items = ['1', '2', '3', '4', '5', '6', '7']
no_over_filler_47_items = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
no_over_filler_17_items = ['H', 'I', 'J', 'K', 'L', 'M', 'N']

prev_hebb_int = ''
prev_hebb_filler = ''


first = True


def doit(block):
    global prev_hebb_int
    global prev_hebb_filler

    global first

    for i in range(12):  # this was 16, but there should be 3 blocks of 4 of these mini-blocks

        # HEBB
        print(block, end='')
        print('hebb  ', end=' ')
        for j in range(len(hebb_items)):
            print(hebb_items[j], end=' ')
        print()

        '''
        Overlap Filler (SP4-7)  1 2 3 [randomised 4 5 6 7]
        '''
        sp47 = hebb_items[3:]
        sp13 = hebb_items[:3]
        random.shuffle(sp47)
        print(block, end='')
        print('over_fill_47 ', end='')
        x = sp13 + sp47
        for i in x:
            print(i, end=' ')
        print()

        # no overlap Filler (SP4-7). Final 4 items randomised
        # this uses a different set of items from the Hebbs
        sp47 = no_over_filler_47_items[3:]
        sp13 = no_over_filler_47_items[:3]
        random.shuffle(sp47)
        print(block, end='')
        print('no_over_filler_47  ', end=' ')
        x = sp13 + sp47
        for i in x:
            print(i, end=' ')
        print()

        # no overlap Filler (SP1-7). Always randomised by PF16
        print(block, end='')
        print('no_over_17_filler ', end=' ')
        for j in range(len(no_over_filler_17_items)):
            print(no_over_filler_17_items[j], end=' ')
        print()

        first = False


for i in range(12):  # this was 16, but there should be 3 blocks of 4 of these mini-blocks
    print('1_hebb 1 2 3 4 5 6 7')
    print('1_no_over_17_filler a b c d e f g')
    print('1_hebb 1 2 3 4 5 6 7')
    print('1_no_over_17_filler a b c d e f g')


# doit('1_')
doit('2_')
