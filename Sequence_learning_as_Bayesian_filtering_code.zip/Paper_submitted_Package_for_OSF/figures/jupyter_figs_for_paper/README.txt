Note: We've now added a new figure 1 (Hebb, 1961, figure 1) so all of
the figure numbers in the filenames are 1 less than they should be)

These files generate the figures in the introduction. They are all
jupyter notebooks incorporating the figures and they should contain
enough documentation to explain how to run them to generate the figs.

Filenames should be self-explanatory

figure1_change_in_particles_over_time.ipynb
samples_plus_simple_hebb_figure2.ipynb
noisy_order_versus_PM_fig3.ipynb
combine_STM_and_LTM_figs_4_and_5_run_all.ipynb


samples_plus_simple_hebb_figure2.ipynb produces the following png files:
hebb_samples_figure2A.png
hebb_samples_figure2B.png

because those figs  need extra resolution.
For the rest, the plots can be copied from the notebooks.

Note that lots of the code generates warnings if you run it with a
recent version of matplotlib. These are just warnings and can be
ignored.

ALternatively you can downgrade to an older version of matplotlib e.g.
conda install matplotlib=3.2.2 (which might not work)

or try one of the fixes here:

https://stackoverflow.com/questions/63723514/userwarning-fixedformatter-should-only-be-used-together-with-fixedlocator
