#!/usr/bin/env python
import random

hebb_items = ['1', '2', '3', '4', '5', '6', '7']
filler_items = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
hebb_filler_items = ['H', 'I', 'J', 'K', 'L', 'M', 'N']

prev_hebb_int = ''
prev_hebb_filler = ''


first = True


def doit(block):
    global prev_hebb_int
    global prev_hebb_filler

    global first

    for i in range(12):  # this was 16, but there should be 3 blocks of 4 of these mini-blocks

        # HEBB
        print(block, end='')
        print('hebb  ', end=' ')
        for j in range(len(hebb_items)):
            print(hebb_items[j], end=' ')
        print()

        # HEBB FILLER
        print(block, end='')
        print('hebb_fill ', end='')
        for j in range(3):
            print(hebb_filler_items[j], end=' ')

        x = hebb_filler_items[3:]
        while True:
            ok = True
            random.shuffle(x)
            if not first:
                for k in range(len(x)):
                    if x[k] == prev_hebb_filler[k]:
                        ok = False
                      #  print('break', x, prev)
                        break
          #  print('AAA', x, prev, ok)
            if x[0] != '4' and ok:
                #print('break2', x, prev)
                break
           # else:
                #              #  print('cont', x, prev)

        prev_hebb_filler = x

       # print('BBB', x)
        for j in range(len(x)):
            print(x[j], end=' ')
        print()

        # HEBB INT - - permutations of Hebb list
        print(block, end='')
        print('hebb_int_filler  ', end=' ')
        for j in range(len(hebb_items)):
            print(hebb_items[j], end=' ')
        print()

        # FILLER list - non-overlapping items
        print(block, end='')
        print('filler  ', end=' ')
        for j in range(len(filler_items)):
            print(filler_items[j], end=' ')
        print()

        first = False


for i in range(12):  # this was 16, but there should be 3 blocks of 4 of these mini-blocks
    print('1_hebb 1 2 3 4 5 6 7')
    print('1_filler a b c d e f g')
    print('1_hebb 1 2 3 4 5 6 7')
    print('1_filler a b c d e f g')


# doit('1_')
doit('2_')
