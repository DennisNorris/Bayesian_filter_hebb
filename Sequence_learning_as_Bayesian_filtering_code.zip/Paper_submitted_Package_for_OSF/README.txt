################################################################

The SIMULATION directory contains a directory for each set of simulations. Each
directory contains a NOTES.txt file explaining the files.  This
directory contains a copy of the default parameters:
100parts_075_100_params

Although there are some spreadsheets in the directories with
preliminary graphs, the final figures are in a 'figures' directory with
the paper. Note that the lines and markers in some of the graphs have
been changed by editing them in the word document.

Directories:


 * program
 
The  simulation program PF16.py and example stimulus and parameter files.
run with: PF16.py PF_example_stimfile.txt PF_example.params > PF_example.out
This example has only a few trials and 20 iterations and takes about 30s to run.

I've also included PF16b_ray.py which is able to use multiple cores
using the ray library.
(22-2-2024: This stopped working on my M1 Macbook Pro when I upgraged to Sanoma.
Works fine on Ubuntu)


SIMULATIONS

* PCN2013_fitted (Figure 7)

Page, M., Cumming, N., Norris, D., McNeil, A., & Hitch,
G. J. (2013). Repetition-spacing and item-overlap effects in the Hebb
repetition task. Journal of Memory and Language, 69(4), 506-526.
Here the model has been fitted to the data (manual grid search)



* SAG2018_new (Figures 8 & 9)

Learning 1 vs 3 Hebb lists with varying number of particles and updates

Saint-Aubin, J., & Guérard, K. (2018). The Hebb repetition effect as a
laboratory analogue of language acquisition: Learning three lists at
no cost. Canadian Journal of Experimental Psychology Revue canadienne
de psychologie expérimentale, 72(1), 2.



* stlouis_PCN2013_March28_2020 (Figure 10)

Simulations of St-Louis et al. 2018 and Page et al. 2013

Varying the number of particles and number of updates for spacings of 4,6 & 9

St-Louis, M.-È., Hughes, R. W., Saint-Aubin, J., & Tremblay,
S. (2019). The resilience of verbal sequence learning: Evidence from
the Hebb repetition effect. Journal of Experimental Psychology:
Learning, Memory, and Cognition, 45(1), 17.

and

Page, M., Cumming, N., Norris, D., McNeil, A., & Hitch,
G. J. (2013). Repetition-spacing and item-overlap effects in the Hebb
repetition task. Journal of Memory and Language, 69(4), 506-526.


* on_off_Schwartz_Bryden (Figure 11) Schwartz, M., & Bryden, M. P. (1971). Coding
factors in the learning of repeated digit sequences. Journal of
Experimental Psychology, 87(3), 331-334.



* bylsma (Figure 12)
Botvinick, M. M., & Bylsma, L. M. (2005). Regularization in short-term memory for serial order. Journal of Experimental Psychology: Learning, Memory, and Cognition, 31, 351-358. doi:10.1037/0278-7393.31.2.351



* mizrak (Figure 13)
Mizrak, E., & Oberauer, K. (2021). Working memory recruits long-term memory when it is beneficial: Evidence from the Hebb Effect. Journal of Experimental Psychology: General.

* alternating (Figure 14)

Cumming, N., Page, M., & Norris, D. (2003). Testing a positional model of the Hebb effect. Memory, 11(1), 43-63.

* KN (table 2)
Kalm, K., & Norris, D. (2016). Recall is not necessary for verbal sequence learning. Memory & Cognition, 44(1), 104-113.



* forward_back (Figure 15)

Guerrette, M.-C., Guérard, K., & Saint-Aubin, J. (2017). The role of overt language production in the Hebb repetition effect. Memory & Cognition, 45(5), 792-803.



################################################################

Running the program:

################################################################

The  simulation program PF16.py is in the directory "program" along with
example stimulus and parameter files.
Run with: PF16.py PF_example_stimfile.txt PF_example.params > PF_example.out
This example has only a few trials and 20 iterations and takes about 30s to run.
The real sims take 30-100 mins each (obviously depending on how fast your computer is).

All of the sims were run with Anaconda python 3.8 under linux or MacOS Mojave.
I've run it on windows in the past.
There's nothing non-standard in the code so it shouldn't be fussy
about which python version/distribution is used.
You might need to install the yaml and tqdm libraries.
yaml is essential for reading the parameter files but tqdm is only
used for a progress bar and the code that invokes it at the
start of run_everything_once can be deleted

Some of the sims were run with PF15.py. The simulation component of
that prog is identical to PF16.py


PF_16b_ray.py uses the ray library to allow the code to run on more
than one core. It splits the iterations between the cores and pools
the results at the end.
This was written after the simulations in the paper but
will produce identical results as the simulation component has not
been changed.

You can get the ray library here:
https://docs.ray.io/en/latest/ray-overview/installation.html

To use it add the parameter 'cores_to_use' and set it to:
    0 to use all available cores
    N to use N cores
   -N to use all but N cores (e.g. with 10 cores setting "cores_to_use: -2" will use 8 cores)



Setting 'cores_to use: 1' (default)  is guaranteed to behave exactly as PF16.py
because then the parallel stuff doesn't get invoked at all.
If more than one core is used, show_progress, verbose, and print_results
are all set to False.



################################################################

parameter files

################################################################

The parameter file names all end with *params. In sims where there are
variations in the parameters the results are in directories called
meaningful_name*params_dir

The output (*.out) files all begin with the full path of the input and
parameter files, program name, and date the sim was run on.  Because
the files have been moved from where they were originally run, the
full path will be wrong. With 100 particles and 1000 iterations most
of the sims take in the order of an hour+ to run on something like an
Intel i7 processor. 100 iterations is enough to get a good idea of
what the simulation is doing and 1000 produces very stable
results. Timing obviously depends on the number of trials.


The param files have several True/False parameter settings, most of
which are vestiges of previous experiments and should not be
altered. The params below are the only parameters that it makes sense
to vary.

LTM_Luce_noise: 0.75
STM_Luce_noise: 0.25
decay: 0.9
backwards_output_decay: 0.9
echoic_boost: 0.0
iterations: 1000
learn_from_presentation_probability: 1.0
learn_from_recall_probability: 0.0
num_particles: 100
print_responses: False
prop_copy_presentation: 0.95
prop_copy_recall: 1.0
show_progress: False
verbose: False



Apart from the sims that explicitly manipulate params and those that
try to fit serial position curves, the sims use the parameters in
100parts_075_100_default.params. These parameters produce a fairly
substantial Hebb effect so it is easy to see the effect of varying
parameters around these values.  The basic Hebb sims are very robust
and insensitive to the exact choice of params. The fussy bit is the serial
position cuves which are mainly determined by the simplified primacy model with
no omissions



################################################################


stimulus files


################################################################

Stimulus files look something like this:

Hebb    1 2 3 4 5 6 7 8 9 0
Filler  1 2 3 4 5 6 7 8 9 0
Filler  1 2 3 4 5 6 7 8 9 0
Hebb    1 2 3 4 5 6 7 8 9 0
Filler  1 2 3 4 5 6 7 8 9 0
Filler  1 2 3 4 5 6 7 8 9 0
Hebb    1 2 3 4 5 6 7 8 9 0
Filler  1 2 3 4 5 6 7 8 9 0
Hebb_1_on_test   a 2 3 4 5 6 7 8 9 0
Hebb_1_off_test  1 2 3 4 5 6 7 8 9 a
Hebb_2_on_test   a b 3 4 5 6 7 8 9 0
Hebb_2_off_test  1 2 3 4 5 6 7 8 a b
Hebb_test        1 2 3 4 5 6 7 8 9 0
Filler_test      1 2 3 4 5 6 7 8 9 0


i.e. a condition label, which can be any text string, followed by the
items to be presented. They can also be any string
e.g.
a_condition_name banana cabbage dog 12 1 a
is a perfectly acceptable line.

The reason the filler lists are all the same in the example is that
the order of items in any condition label containing "filler" (in any
case or mixture of cases) gets randomised on each presentation unless
the parameter shuffle_fillers is set to False.

If the label contains "test" (in any case) the particles/LTM do not
get updated so you can have a set of tests at the end to probe a fixed
state of the system unless force_update_after_tests is True.

You can also control whether recall is forward (the default - don't
really need this) or backward by including either forward or backward
in the label.  e.g.

forward_Hebb          a b c d e f g
backward_Hebb         a b c d e f g


################################################################

output

################################################################

The output files all begin with details of how and when the program was run e.g:

input file: /Users/dennis/ownCloud/PF_RESTORED/PF/benchmarks/2020_in_paper_only/program/PF_example_stimfile.txt
parameter file: /Users/dennis/ownCloud/PF_RESTORED/PF/benchmarks/2020_in_paper_only/program/PF_example.params
Command line: ./PF16.py PF_example_stimfile.txt PF_example.params
CWD: /Users/dennis/ownCloud/PF_RESTORED/PF/benchmarks/2020_in_paper_only/program
Run at:  09:36 on 20/01/2022


The directory paths in the simulations are no longer meaningful as all
of the output files have been moved form their original locations.

NB some of the sims were run with a previous version of the program
PF15.py, but the simulation component of the two programs is identical.


The program prints out all of the parameters in a form that can be just
cut-and-pasted into a parameter file.

For each condition the results of the sims look like this:

hebb: 0.59, 0.1583
Position means: hebb : 0.85  0.60  0.50  0.50  0.52  0.40  0.48  0.67  0.77
Repeats: hebb : 0.43  0.59  0.74


where:
# condition label, overall mean correct in position, slope accross presentations
hebb: 0.59, 0.1583 

# items correct in position
Position means: hebb : 0.85  0.60  0.50  0.50  0.52  0.40  0.48  0.67  0.77

# mean for each presentation of this condition (here there are only 3 repetitions)
Repeats: hebb : 0.43  0.59  0.74  

As would be expected, slopes for filler/unique lists are always pretty close to zero.

Setting the parameter
print_responses: True
prints out the presented and recalled sequence for every trial for
every simulated subject, not just the means.

verbose: True
prints out loads of stuff that you almost certainly don't care about.
This is mainly for checking that the program is doing what we expect it
to do.
