#!/usr/bin/env python
# -*- coding: utf-8 -*-

from copy import copy
from copy import deepcopy
from unicodedata import name
import numpy as np
import math
import random
from scipy import stats
import sys
import os
import time
from sys import stdin  # for testing on windows
from sys import platform as _platform
import yaml  # for reading parameters from file
from pprint import pprint
from tqdm import tqdm   # progress indication
import ray

version = 'PFparallel using ray.  Derived from 16.2'


"""@author: dennis

Use:
PF16.py input_file parameter_file

This version has the optimisation and converge code removed and
warings added if you try to set any of the unused options.
For compatibility with older param files it wont complain if you
set things like: learn_converge: False.


**************** Input file format *****************************

An input file might go something like this:

filler H A I B G E F D C
hebb   A B C D E F G H I
filler I H G F E D C B A
filler E I D H A C G B F
hebb   A B C D E F G H I

i.e. condition label followed by the list.
Label and list items can be any string with no spaces.
Lists can be any length.

If a label contains "filler" anywhere (case doesn't matter) the order
is randomised on each trial. You can control this by setting the parameter:
shuffle_fillers: True/False

If a label contains "test" it doesn't update the particles after that
list - so it has no effect on subsequent lists. This means you can put
lots of test list at the end of the simulations and they will all be
processed with the model in the same state.

You can control this  by setting the parameter:
force_update_after_tests: False/True

*****************  Parameter file   ****************************

These are the default params from: 100parts_075_100_default.params

Parameters go like this:

LTM_Luce_noise: 0.75  # can put comments after #
STM_Luce_noise: 1.0
allow_backwards_recall: False
allow_decay_during_input: False
always_do_backwards_recall: False
backwards_output_decay: 0.9
converge_random: False
convergence_factor: 0.5
decay: 0.9
echoic_boost: 0.0
force_update_after_tests: False
iterations: 1000
learn_converge: False # we don't use the converge option
learn_from_presentation_probability: 1.0
learn_from_recall_probability: 0.0
num_particles: 100
particle_setup_length: True
particle_setup_noise: 0.001
particle_update_noise: 0.75
posterior_by_multiple_recalls: True
print_responses: False   # prints every trial
prop_copy_presentation: 0.95
prop_copy_recall: 1.0
show_progress: False
shuffle_fillers: True
strict_position_score: True
verbose: False

All parameters have defaults if they aren't given.

The colon is essential. Can follow the parameter with a comment.
See start of main to see which params can be set. Should make sure
that everything can be set.

The prog begins by printing out all of the params in a form that can
be just cut-and-pasted into a parameter file.
Actually, there are a few that don't get printed out, which should be fixed,
but they are settable.


For each condition the results of the sims look like this:

hebb: 0.59, 0.1583
Position means: hebb : 0.85  0.60  0.50  0.50  0.52  0.40  0.48  0.67  0.77
Repeats: hebb : 0.43  0.59  0.74


where:
hebb: 0.59, 0.1583  # overall mean correct in position, slope accross presentations
# items correct in position
Position means: hebb : 0.85  0.60  0.50  0.50  0.52  0.40  0.48  0.67  0.77
Repeats: hebb : 0.43  0.59  0.74  # mean for each presentation of this condition.




****************************************************************





One thing that would help the code is to have a sequence object
that would hold the items and the gradient and have helper fns to
convert between indexes and items etc. That would clean up quite a
few of the messy bits.

Might be a good idea to have an item object which could contain
position, index, id and any item inforation we want to add later - such as a
featural representation.

There are also some old things that should be
removed. e.g. optimisation was rather pointless and too slow to be
practical. It is disabled, but the code is still there.

There's stuff relating to the 'converge' procedure which was never any
use and that should be removed too.


****************************************************************




The simplest summary of the recall process is that order is
represented as a gradient/activations where the relative 'activations'
determine order. We turn those activations into recall probabilities
by applying Luce (softmax) and then use the weighted_choice
fn which does the equivalent of adding noise and picking the
biggest. The effective noise is given by the parameter STM_Luce_noise.

The same happens with the LTM particles to generate a prior. LTM uses
LTM_Luce_noise. We sum the probability of recalling each item next
over all particles.  The contribution of each particle is weighted by
how probable that particle is to have generated the sequence so
far. The priors over items are therefore conditional on what's been
recalled so far. If the input is 1234567 then, by the time you've
recalled 1234, a particle representing 7654321 will have negligible
influence because the P of that particle having generated the sequence
1234 is near zero.

Particles are initialised at random using particle_setup_noise. After
each list some proportion of the particles (prop_copy_presentation)
have their weights changed. New weights are generated from the input
list gradient + particle_update_noise.

If we update on every trial Hebb learning is a bit too fast, so we can
slow things down by lowering learn_from_presentation_probability so
that we don't update on every trial. 0.25 seems OK.




Issues.

In comments I'm using 'weights' to refer to the steps in the gradient
but also to refer to the weighting of each LTM particle during recall.
In STM the gradient acts like the activati1592
on gradient in the Primacy model.



Moving between input lists, and gradients and back again is messy.
We start with an ordered list of all possible items e.g.


vocabulary ['1', '2', '3', 'a', 'b', 'c',
    'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k']

run_PF gradient:  [3, 1, 2, 11, 10, 9, 8, 7, 6, 5, 4, -inf, -inf, -inf]
Hebb_offset_changed memoranda:    ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', '1', '3', '2']
Hebb_offset_changed memoranda_by_index:  [3, 4, 5, 6, 7, 8, 9, 10, 0, 2, 1]
Hebb_offset_changed response by index:   [3, 4, 5, 6, 7, 8, 9, 10, 2, 1, 0]




and then each list is represented as a positional gradient over those
items, with any items not in the list having a gradient/activation of
-Inf

e.g. the list e,d,c,b is represented by the 'activations': [-Inf,
1,2,3,4, -Inf ..]  Then, at recall, we're going to do a primacy-like
pick the biggest.  Each item-recall recall should find the index with
the biggest activation.  At the end of recall we will have a list of
the indexes indicating the order of the items recalled which, in this
case, is going to be [5,4,3,2] Finally, we can use these indexes to
recover the list e,d,c,b.

NB we're not actually using pick-the-biggest. We calculate the P of
recalling each remaining item next using the Luce so that we've got
probabilities we can multiply, then we choose the next item by random
sampling weighted by those probabilities.

However, most of the time we just use 'activations' at positions, because
we only need to go from the input list once, and from the gradient to
the output list if we want to print it out in a human-readable form.




In Trial we have these as
self.memoranda  = [] # e,d,c,b
self.memoranda_by_index = [] # [5,4,3,2]

We only end up with the list of recalled items in Result. That is only
really necessary for scoring protrusions because there you want to be
able to go back and analyse the relation between successive recalls.

Maybe we should keep a copy of everything in Result.

result.memoranda
result.memoranda_by_index
result.items_recalled
result.items_recalled_by_index



NB sometimes the Hebb slope can be low because it learns too fast on
the first presentation and is flat thereafter. This can be fixed by
lowering the probability of learning from presentation or recall.


=====================================================



"""

################################################################
#
#                Params
#
# This should contain all of the parameters that need to be passed
# around or used anywhere
#
# Maybe all of the params shoud be in a dict, to help reading in and printing
# but I thought that might slow things down, but it would probably
# have made a negligible difference.
# param_dict now contains the settable params which solves the reading/
# printing problem
#
################################################################


NEGATIVE_WEIGHT = -50.0  # This is the weight for items not in the list
# it used to be -np.Inf


class Params(object):
    """
    """

    def __init__(self):
        """
        """
        self.print_responses = False     # print individual responses
        self.verbose = False  # prints loads of detail if True

        self.strict_position_score = True  # else use Levenshtein
        # doesn't do this any more
        self.iterations = 50
        self.iteration_count = 0
        self.num_particles = 20

        self.trial_list = []    # we'll keep a copy of the trial list here to
        # save passing it around
        self.trial_types = []  # list of the different kinds of trial

        self.results_dict = {}  # dict with the conditions (e.g. Hebb,
        # Filler) as keys and a Results object as value

        # list_length & num_items are now derived form the input file
        self.max_list_length = 8  # at the moment all lists have to be the
        # same length, so we derive it from the
        # input

        self.num_items = 8  # number of distinct items. We don't allow
        # repeats.

        self.gradient_length = self.num_items  # gradient_length is
        # always the same as num_items now

        self.num_trials = 1  # this is set from the input file
        self.minimum_weight = 0.0
        self.vocabulary = []  # the set of items found in the input file

        # Next are the parameters to control the copy proportion for
        # presentation and recall separately, and also control the
        # probability of learning from presentation or recall.  These
        # are fixed proportions, not the probability of copying each
        # particle, so you don't want to set these as 0.95 if you have
        # only 10 particles.
        self.prop_copy_recall = 0.0
        self.prop_copy_presentation = 0.9

        self.learn_from_recall_probability = 0.0
        self.learn_from_presentation_probability = 1.0

        # controls whether you can disable update after trials beginning
        # with 'test'
        self.force_update_after_tests = False
        self.decay = 0.9  # 1.0 means no decay
        # separate decay for output during backwards recall
        self.backwards_output_decay = 0.9

        self.allow_decay_during_input = False

        self.allow_backwards_recall = False  # allow backwards recall.
        # We don't have this as default as it adds extra complexities that we
        # can normally do without.

        self.always_do_backwards_recall = False  #
        # boost last item presented - only if allow_backwards_recall True
        self.echoic_boost = 0.0
        self.STM_Luce_noise = 1.25  # Luce choice parameter for
        # STM/primacy model

        self.LTM_Luce_noise = 0.05  # Luce choice parameter for
        # generating priors form particles

        self.particle_setup_noise = 0.001  # uniform noise in
        # initialising sequences/weights of particles
        self.particle_setup_length = True  # initialise particles to represent
        # lists of this length

        self.particle_update_noise = 0.1  # noise to add when updating
        # particles (i.e. generating new ones) when learning from recall

        self.show_progress = False  # this just controls printing of progress

        # we no longer do optimisation
        self.optimising_condition = ''

        self.shuffle_fillers = True  # set to True to shuffle order of
        # items in all filler trials i.e. trials with
        # 'filler' anywhere
        # It's not case sensitive, so FiLler99 works

        # These converge parameters should be removed
        # They no longer do anything
        self.learn_converge = False
        self.convergence_factor = 0.5  # 1.0 is instant convergence_factor
        self.converge_random = True

        self.posterior_by_multiple_recalls = False
        self.cores_to_use = 1  # set to 0 to use all available cores


'''parameter_dict must contain copies of the parameters that appear in
params and can be set in the yaml file. read_yaml_file checks that
each parameter in the input actually exists and sets the param to its
new value if it does.  The initial values in param_dict don't matter
as they're first set from params.


   'max_list_length':  7,
    'num_trials': 34,
    'num_items': 7,
    'gradient_length': 7,


'''


param_dict = {
    'num_particles': 20,
    'iterations': 100,
    'prop_copy_recall': 0.0,
    'prop_copy_presentation':  0.95,
    'learn_from_recall_probability': 0.0,
    'learn_from_presentation_probability': 0.25,
    'force_update_after_tests': False,
    'LTM_Luce_noise': 0.25,
    'STM_Luce_noise': 0.75,
    'particle_update_noise': 0.1,
    'particle_setup_noise': 0.001,
    'particle_setup_length': True,
    'shuffle_fillers': True,
    'show_progress': False,
    'optimising_condition': '',
    'decay': 0.9,
    'backwards_output_decay': 0.9,
    'allow_backwards_recall': True,
    'always_do_backwards_recall': False,
    'allow_decay_during_input': False,
    'echoic_boost': 0.0,
    'strict_position_score': True,
    'print_responses': False,
    'verbose': False,
    'learn_converge': False,
    'convergence_factor': 0.5,  # 1.0 is instant convergence_factor
    'converge_random': False,
    'posterior_by_multiple_recalls': False,
    'cores_to_use': 1
}


'''processes the params listed in params_dict from a yaml and uses
that dict to set the params. It also checks to see whether the_params
are in the dict.  Doesn't do any sanity checking on types but we do
check on values of some params at the end of main.

'''


def read_yaml_params(yaml_params):
    """ set and print parameters from a yaml object"""

    for key in param_dict:  # the list of params we can set
        toex = 'param_dict[\''+key+'\']=params.'+key
        exec(toex)

    for key in yaml_params:
        if key not in param_dict:
            print('ERROR: \'', key,
                  '\' is not a settable parameter. Could it have been mistyped?')
        else:
            param_dict[key] = yaml_params[key]
            if type(yaml_params[key]) is str:
                toex = 'params.'+key+'=\'' + yaml_params[key]+'\''
            else:
                toex = 'params.'+key+'=' + str(yaml_params[key])
            exec(toex)

    for key in sorted(param_dict.keys()):  # sort the dict, otherwise order is random
        print("{0:s}:".format(key), param_dict[key])


'''
This prints the parameters listed in param_dict by creating and 'exec'ing
a string like
param_dict['decay'] = params.decay and then printing the dict.

'''


def print_params():
    """ print the parameters in param_dict"""
    for key in param_dict:
        toex = 'param_dict[\''+key+'\']=params.'+key
        exec(toex)

    for key in sorted(param_dict.keys()):
        print("{0:s}:".format(key), param_dict[key])


'''

This uses three different noise parameters
1. noise used to initialise the particle sequences (weights)
2. noise used when particles are updated. This would be zero if the new
particle was just a copy of the weights of the input or the racalled pattern.
3. Noise parameter for the Luce choice rule for generating the priors from LTM
or the likelihoods from STM

'''


'''################################################################


A Particle object is a particle, node, or whatever you want to call it.
It functions as the LTM particles and we use a single particle for STM.
The most important part of an LTM particle is its gradient (or
weights) which is what represents its order. In primacy model terms
the weights in the STM particle can be thought of as activations.

If the set of items we use is the ordered list ABC, the gradient 3,2,1
= ABC and  1,2,3 = CBA. Each gradient value will be noisy and will
start from a uniform distribution.

To initialise a new LTM particle pass it an 0-length gradient and
particle_setup_noise which controls the range of initial random
gradient/weights.

luce_noise controls precision/generalisation of the particle which
determines how finely tuned it is to a specific sequence. Currently
this is the same for all LTM  particles.

For an STM particle it acts like the choice noise in the Primacy model.
We give each particle an index/ID. This was only ever used for debugging.
# Why am I explicitly passing things that are accessible through params?
# should just be Particle(params, [],  index,  trial)

################################################################


The initialisation procedure is a bit if a mess and should be cleaned up.
We always run it with  self.params.particle_setup_length = True now
which sets it up as a random gradient of integers covering a list,
not the whole gradient. e.g. a 3-item list from a set of 5 items
might be [1,NEGATIVE_WEIGHT,3, NEGATIVE_WEIGHT, 2]



'''


class Particle(object):
    def __init__(self, params, gradient, luce_noise, particle_setup_noise, particle_update_noise, index, trial):
        """ particle object. Initialise from gradient,  number of items, and
        variance.
        if len(gradient) == 0, initialise at random.
        We just call this luce_noise because STM is also a particle
        """
#        print("creating particle ", index)
        # self.gradient is just a random activation gradient
        self.gradient = copy(
            gradient)  # This shouldn't be necessary any more

        self.luce_noise = luce_noise
        self.particle_update_noise = particle_update_noise
        self.params = params
        self.suppressed = [False] * self.params.gradient_length
        self.trial = trial
        self.weight = 1.0  # this keeps track of the weighting given to the
        # probability of item recalls for this particle.
        # e.g. if the first item actually recalled would only have a proby of
        # 0.1 of being recalled by this particle, the weight is multiplied by 0.1
        # so that its future contribution decreases
        self.distance = 0  # Euclidian distance from input gradient

        self.last_recall_Ps = np.zeros(self.params.num_items)
        self.index = index

        '''This is a bit messy.
        1. If gradient empty, and params.particle_setup_length is
        True, use weights 1-N and when there are more items in total
        (M) than there are in the list (N) you need to initialise N
        weights and fill the remainder with -Inf (or NEGATIVE_WEIGHT)

        2. elseif gradient empty and self.params.particle_setup_noise
        == 0, the set the gradient to 1-M

        '''

        if len(gradient) == 0:  # if gradient is empty just initialise with
            # random uniform

            # construct initial gradients by randomising 1..N and then adding noise

            # GRADIENT FIXED
            '''23-01-2019 There was a bug here. random.uniform takes
            (low, high, length) so this would typically have been producing uniform in
            range something like 7/2 - 0.001. All we need here is for the gradient
            to be random, so it shouldn't change much.

            newGradient = [float("inf")] * self.params.gradient_length
            for i in range(self.params.gradient_length):
                newGradient[i] = random.uniform(self.params.num_items / 2.0,
                                                particle_setup_noise)  # random.random() * self.num_items


            if particle_setup_noise is <= 0 just set the all of the
            gradient to self.params.num_items/2.0
            if particle_setup_noise == 0 just create a randomly ordered gradient
            If particle_setup_noise > 0.000001 set gradient to mean + noise



            '''
            # this sets weights in range max_list_length
            if self.params.particle_setup_length:  # random order, no noise on weights
                new_gradient = np.arange(
                    self.params.max_list_length, 0.1, -1.0)  # something like 5,4,3,2,1,
                tmp = np.full(
                    self.params.gradient_length-self.params.max_list_length, NEGATIVE_WEIGHT)
                # print('ng', type(new_gradient))
                # print('tmp', type(tmp))
                new_gradient = np.concatenate((new_gradient, tmp))
                random.shuffle(new_gradient)

            # if -ve set gradient to random sequence over the FULL gradient
            # Should maybe be random sequence the same length as the exptl. lists?
            # I'm worried that this may differ between small/large sets of items.
            # if we ever make direct comparisons.
            # The simple solution is to always have one list (could be the last)
            # with all items even if you're just using a subset so that the vocabulary,
            # and hence the gradient length is always the same. This is now what I
            # always do. But shoud fix it properly.

            # and this sets weights in range gradient_length
            elif self.params.particle_setup_noise < 0.000001 and self.params.particle_setup_noise > -0.000001:
                new_gradient = np.arange(
                    self.params.gradient_length, 0.1, -1.0)
                random.shuffle(new_gradient)

            # if -ve, then set gradient to -inf. This will make it be treated
            # as suppressed. i.e. make no contribution.
            else:  # self.params.particle_setup_noise -ve
                new_gradient = np.full(
                    self.params.gradient_length,  NEGATIVE_WEIGHT)

        elif particle_setup_noise <= 0.0:
            self.gradient = copy(gradient)
            return

        else:  # initialise by adding particle_setup_noise to gradient given

            print(
                'in Particle _init_. I dont\'t expect this to get here any more', self.index)
            new_gradient = np.random.normal(gradient, particle_setup_noise)

        self.gradient = new_gradient
#        print('Particle', self.gradient)

    '''update_one_particle()
    This recycles existing particle objects initialising the weights
    from the input list (the sequence, not the gradient).
    It doesn't construct new particles.
    When called in the multiple updates from posterior mode the noise
    will be zero because this is just being passed the recalled sequences
    '''

    def update_one_particle(self, memoranda_by_index, update_noise):
        """ updates particle from (index, update_noise). Overwrites gradient
        """

        new_gradient = index_to_gradient(
            memoranda_by_index, self.params.gradient_length)
#        print('update_one_particle A', self.index, memoranda_by_index, self.gradient,  new_gradient, update_noise) #DELETE_ME

        # only attempt to add noise if noise > 0
        if update_noise > 0.0:
            new_gradient = np.random.normal(new_gradient, update_noise)

        self.gradient = new_gradient


########################################################
#  get_remaining_item_recall_probabilities_for_one_particle()
#
#  Returns an array of the probabilities that
#  each item will be recalled next.
#
#  All it really does is call get_luce_probies_for_one_particle() and do a bit
#  of error checking
#
#  Suppressed items will have P=0.  The array is multiplied by
#  the weight of the particle i.e. the P that the items already
#  actually recalled would have been recalled according to this
#  particle
#
#  Called from recall_from_STM() - on all particles
#  The gradient is therefore the STM input gradient or the
#  particle gradient
#
#
#
########################################################


    def get_remaining_item_recall_probabilities_for_one_particle(self, trial, is_presentation):
        """Returns list of recall Ps. trial is a Trial
        """
        '''
        print('get_remaining_item_recall_probabilities_for_one_particle A',
              self.index, self.gradient)
        '''
        # this is a primacy gradient i.e. large to small.
        # do we really need a  copy here?
        tmp_gradient = copy(self.gradient)

        # reverse/invert the particle gradient (not if STM particle)
        # but don't do it if we are in presentation. This should only happen
        # with multiple_samples as we need to do multiple samples
        # from 'recalling' the input for that
        # We never reverse if we're just dealing with presntation
        if trial.backwards and self.index >= 0 and not is_presentation:
            tmp_gradient = reverse_gradient(self.gradient)

        self.last_recall_Ps = self.get_luce_probies_for_one_particle(
            tmp_gradient, self.suppressed, self.luce_noise)

        # the rest of this is just error checking to catch NaNs or Ps< 0
        # Never seems to happen any more
        for i in self.last_recall_Ps:
            if math.isnan(i):
                print(
                    'nan ERROR in get_remaining_item_recall_probabilities_for_one_particle - self.last_recall_Ps', self.index)

        if sum(self.last_recall_Ps) < 0.0:  # this was <= 0.0, but can be 0 11-11-2018
            print('\n\nERROR: get_remaining_item_recall_probabilities_for_one_particle. last_recallPs == 0:', self.index,
                  '\n', 'self.last_recall_Ps', self.last_recall_Ps, '\n')
            print('gradient', tmp_gradient)
            print('get_remaining_item_recall_probabilities_for_one_particle ', self.index,
                  '\n', len(self.suppressed), self.suppressed)
            print(len(self.last_recall_Ps), '\nself.last_recall_Ps:',
                  self.last_recall_Ps, '\n')
            print('Trial no:', self.trial.trial_number +
                  1, ' list length: ', self.trial.list_length, '. list:', self.trial.memoranda)

        return self.last_recall_Ps * self.weight

    ####################################################
    #              get_luce_probies_for_one_particle()
    #
    # This takes the input activations, the suppressed list, and the noise
    # parameter and then uses the Luce choice formula to return a list of
    # the probabilities of choosing each item (index).  Items/indexes that
    # are already suppressed are ignored i.e. P=0.
    #
    # For backward recall we will have reversed the gradient
    # already in  get_remaining_item_recall_probabilities_for_one_particle
    #
    #
    #
    ####################################################

    '''
    This:
    luce_noise = math.sqrt(2.0) / sd
    Is required to make the noise parameters approximate  sd

    This is the only place where luce_noise is used
    For the luce choice rule (see McClelland & Elman 1986, p21)
    math.exp(constant * activation)
    which we have below as
    math.exp(luce_noise * (val - lowest))


    '''

    def get_luce_probies_for_one_particle(self, inp, supp, sd):
        """ inp= activation gradient, supp = bool array, True if suppressed, sd=noise
        """
        if(len(inp) == 0):
            print("ERROR in get_luce_probies_for_one_particle - inp is zero-length")
            sys.exit()

        out = np.zeros(len(inp), dtype=np.float64)
        exps = np.zeros(len(inp), dtype=np.float64)

        # Shouldn't keep doing this sqrt/sd n here .
        # Should do it once when reading the params in?
        # Should probably make things clearer by calling this luce_k and having
        # variables STM_k and LTM_k whcih are derived from STM_noice and
        # LTM_noise when the params are read in.
        # We need this to generate a value of k which makes it behave like
        # noisy choice with standard deviation of sd.

        luce_noise = math.sqrt(2.0) / sd  #

        ''' suppressed items are -inf, so to find the
        smallest activation remaining we need to find the min > 0
        But if we've set the gradient to -inf all round we're
        effectively saying that this particle contributes nothing,
        so return zeros
        '''
        if max(inp) < 0.0:
            return out

        # lowest = min(x for x in inp if x >= 0.0)

        '''This line above is where we run into trouble because it's got to
        end up with val - lowest being zero at some point

        '''

        # this loop is almost certainly where it's spending most time
        # There must be a more efficient numpy way of doing this.
        try:
           # print('get_luce_probies_for_one_particle input', inp, supp)
            for i, val in enumerate(inp):
                if not supp[i]:  # ignore items that have been suppressed
                    try:
                        exps[i] = math.exp(luce_noise * val)
                    # if we get an overflow error in prev line set exps[i]
                    # to max float
                    except OverflowError:
                        # the consequence of this is to make all such items
                        # have same value
                        exps[i] = sys.float_info.max
                        print('Overflow in get_luce_probies_for_one_particle')
                else:
                    exps[i] = 0.0
        except:
            print("Error in get_luce_probies_for_one_particle:", len(
                inp), inp, len(supp), supp, i, val, exps[i])

        try:
            sum_exps = sum(exps)
        except OverflowError:
            sum_exps = sys.float_info.max

            # not sure why this doesn't give overflow errors too
        if sum_exps > 0.0:   # when we're forgetting items sum_exps can be 0
            #  if we've done this line above it could overflow
            # here: exps[i] = sys.float_info.max
            # just make it sums to 1 -
            # could set it to 1. All that matters is that it contributes
            # equally to all items
            out = exps/sum_exps
        else:
            out *= 1.0/len(inp)

        # sum(out) can be zero if everything suppressed

        if sum(out) < 0.0:
            print('ERROR in get_luce_probies_for_one_particle: inp= ',
                  inp, 'supp=', supp)
        return out

    def suppress_by_index(self, i):
        """ suppresses item with index i and updates the particle weight
        """

        if i > len(self.suppressed):
            print("index out of range in suppress_by_index", i)
            exit()
        self.suppressed[i] = True
        # update the weight by the P that the item was recalled in this posn
        self.weight *= self.last_recall_Ps[i]
        if self.params.minimum_weight > 0.0:
            self.weight = min(self.weight, self.params.minimum_weight)

    def reset(self):
        """Resets the particle suppressed list and weight
        """
        self.suppressed = [False] * self.params.gradient_length
        for ind, val in enumerate(self.gradient):
            # this should be redundant:
            # make sure items with -Inf gradients are considered to be s
            # uppressed already
            if val < 0.0:
                self.suppressed[ind] = True
        self.weight = 1.0

#########################################################
#
#        Memory object - holds the particles
#  should change these self.num_items things to access the params directly
#
#########################################################


class Memory(object):
    """Contains all of the particles.
    Initialise with number of particles, number to update,
    length of lists and variance, all taken from params which is the only arg.
    """

    def __init__(self, params):
        # params.num_particles should be an int anyway,
        # but linux wants a cast here
        self.N = int(params.num_particles)
        self.num_items = params.num_items
        self.params = params
        dummy_trial = Trial()
        #  create all of the particles initialised at random
        # Particle needs: params, gradient, luce_noise, setup_noise, update_noise, index, trial):
        # Why am I explicitly passing things that are accessible through params?
        # should just be Particle(params, [],  _,  dummy_trial)
        self.particles = [
            Particle(params, [], params.LTM_Luce_noise, params.particle_setup_noise, params.particle_update_noise,
                     _,  dummy_trial) for _ in range(self.N)]

        # an array of indices that we keep on shuffling
        # to sample a random subset of items to be updated
        self.particle_indexes = [k for k in range(self.N)]

    # For the particles that are being copied this does nothing
    # For the rest it generates new particles generated from
    # the input/observation
    # NB - we only ever update the LTM particles - no point in updating the
    # STM particle.
    # The gradient here is the input/current state
    # So long as the index is left or reconstructed in the forward
    # order we don't need to do anything special here for backwards recall.
    # This isn't used when generating samples from the posterior (recall)

    def update_some_particles(self, memoranda_by_index, copy):
        """For the particles that are being copied this now does nothing.
        For the rest it generates new particles generated from the
        input/observation.

        'copy' specifies proportion of particles to copy
        """
#        print('update_some_particles', self, memoranda_by_index) #DELETE_ME
        num_update = int(params.num_particles -
                         copy * params.num_particles)

        # shuffle indexes to randomly select subset of particles to update
        random.shuffle(self.particle_indexes)
        # update both the gradients
        for i in range(num_update):
            self.particles[self.particle_indexes[i]].update_one_particle(memoranda_by_index,
                                                                         self.params.particle_update_noise)  # update particles

    '''Recall can be considered to be taking a single sample from the
    posterior. If we want to update using samples from the posterior
    we need to do multiple recalls/samples and use those samples to
    update the particles


    DELETE_ME by the time we get here the forward and backward from
    presentation are different

    '''

    def generate_samples_by_recall(self, prop_copy, gradient, trial, is_presentation):
        """
        args:
        param1: proportion of particles to be copied (i.e. not updated)
        param2: the gradient
        param3: trial
        param4: whether were doing this at the end of presentation or after recall. (bool)
        """

        response_samples = []
        n_samples = int(params.num_particles -
                        prop_copy * params.num_particles)

        # first generate the samples (i.e. responses)
        for i in range(n_samples):
            response = self.recall_from_STM(gradient, trial, is_presentation)
            # response is the sequence of positions recalled
            # ignore anything beyond the length of the list such as words not in the set
            response = response[0: trial.list_length]
            response_gradient = index_to_gradient(response, params.num_items)
            if trial.backwards and not is_presentation:  # reverse response if we're doing backward recall
                response = response[::-1]
            response_samples.append(response)

        # shuffle indexes to randomly select subset of particles to update
        random.shuffle(self.particle_indexes)

        for i in range(n_samples):
            self.particles[self.particle_indexes[i]].update_one_particle(
                response_samples[i], 0)  # update particles

    def recall_from_STM(self, list_gradient, trial, is_presentation):
        """Returns list of the indexes of recalled items.

        gradient is input
        STM is a particle
        """

        # create our STM - a particle just like any other.  Particle
        # needs: length, gradient, memoranda, luce_noise, setup_noise,
        # update_noise, index): NB the particle index is set to -99
        # which helps identify the STM particle when printing error
        # messages We pass trial too, so we can print the input for
        # errors recall is actually done by successive calls to
        # get_remaining_item_recall_probabilities_for_one_particle(trial)
        # Would be cleaner to do this when setting the trials up at
        # the start
        # NB we don't want
        # create_forwards_backwards_gradient if we're doing updates
        # from the posterior from input
        # not_is_presentation was missing before 9-10-19
        if params.allow_backwards_recall and not is_presentation:
            forwards_gradient, backwards_gradient = create_forwards_backwards_gradient(
                params, trial=trial, num_items_rehearsed=0)

            '''            
            the following means that when we're doing backwards recall
            and sampling from the posterior after presentation we'll
            do it backwards. Is what really what we want?  It doesn't
            actually make any sense to do multiple samples from teh
            posterior from recall as this is really the same as doing
            it form the input, unless we we're to allow noise or decay
            to be different between input and recall sampling (as
            opposed to actual recall)
            
            '''

            if trial.backwards:
                STM = Particle(params, backwards_gradient,
                               self.params.STM_Luce_noise, -99.0, -99.9, -99, trial)
                gradient = copy(backwards_gradient)
            else:
                STM = Particle(params, forwards_gradient,
                               self.params.STM_Luce_noise, -99.0, -99.9, -99, trial)
                gradient = copy(forwards_gradient)
        else:  # normal operation. No decay during input.
            STM = Particle(params, list_gradient,
                           self.params.STM_Luce_noise, -99.0, -99.9, -99, trial)

            # use a copy as we might mess with it here,
            # and don't want to change the gradient in the  trial_list
            gradient = copy(list_gradient)

        list_indexes = [x for x in range(params.num_items)]
        recall = []  # holds indexes of recalled items

        minimum_proby = [0.0001] * params.num_items

        # I think this should be redundant too. 11-11-2018
        # make sure any items with a -Inf gradient (not presented)
        # are set to be suppressed
        for ind, val in enumerate(gradient):
            if val < 0.0:
                STM.suppressed[ind] = True
        # for each position this contains the weighted sums of the
        # probability that each particle would have recalled each item
        # in each position.

        particle_probies = np.zeros(self.num_items)

        for p in self.particles:
            p.reset()  # reset the suppressed list and weights of all particles
#            print('recall_ffrom_STM', p.index, p.gradient)
        # for each list position loop through all particles
        # print('\n0 recall_from_STM:', trial.memoranda, trial.condition)
        for listPos in range(trial.list_length):
            #            print('recall_from_STM', listPos)
            particle_probies.fill(0.0)
            for p in self.particles:
                # this is giving us array of weighted Ps
                tmp = p.get_remaining_item_recall_probabilities_for_one_particle(
                    trial, is_presentation)
                # print('A recall_from_STM:',  listPos, p.index, tmp,  p.weight)
                # print('A recall_from_STM:',  p.index, p.gradient)
                if math.isnan(tmp[0]):
                    print("nan ERROR in recall_from_STM", listPos, p.index)
                particle_probies += tmp  # this will add with float or np array

            # print('B recall_from_STM:', listPos, particle_probies)

            particle_probies += minimum_proby  # make sure the prior never goes to zero

            # this is what sometimes goes to zero
            STM_list_Ps = STM.get_remaining_item_recall_probabilities_for_one_particle(
                trial, is_presentation)

            if sum(STM_list_Ps) <= 0.0:
                print("\nERROR: recall_from_STM STM_list_Ps are zero. list posn:",
                      listPos + 1, ' (counting from 1)')
                sys.exit()

            if particle_probies.sum() > 0.0:
                particle_probies = particle_probies / particle_probies.sum()  # normalise
                posterior_proby = particle_probies * STM_list_Ps
                posterior_proby = posterior_proby / posterior_proby.sum()
            else:
                posterior_proby = STM_list_Ps  # in case all particle ps are zero

            # print('\nC recall_from_STM:', listPos, particle_probies)
            # print('D recall_from_STM:', listPos,  STM_list_Ps)
            # print('E recall_from_STM:', listPos, posterior_proby, '\n')

            # choose an item to recall based on the probabilities
            '''
            item_to_recall_index = weighted_choice(
                list_indexes, posterior_proby)

           '''

            item_to_recall_index = np.random.choice(
                list_indexes, p=posterior_proby)

            # now we need to suppress the same items in the particles
            # because P(recall that item) | (we've recalled it already) = 0
            for p in self.particles:
                p.suppress_by_index(item_to_recall_index)
            STM.suppress_by_index(item_to_recall_index)
            STM.weight = 1.0  # FUDGE - don't want to downweight STM

            # and we also set the gradient/activation for this item to -Inf.
            gradient[item_to_recall_index] = NEGATIVE_WEIGHT

            # add this item to the recalled sequence
            recall.append(item_to_recall_index)

            '''the logic of this is that we don't do any decay if we're in
            presentation. The only time we'll be rdoing 'recall'  then is to
            gererate samples from the posterior.

            If we're doing recall either to actually recall the list,
            or to generate samples from the posterior, then we want to
            use decay, obviously only if it's < 1.0, and which decay
            we use depends on whether it's forwards or backwards
            '''
            '''CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK 

            Have I got completely confused? If we do sampling from the posterior
            at the end of input how does that differ from at end of output?  There
            has to be a difference in decay, or in either LTM or STM noise.  LTM
            noise must surely be the same. We could say that STM noise was less at
            input than at output as there's less time for decay.  Currently, I'm
            testing it without any decay and the noises should be the same so it
            shouldn't matter whether I do updating by multiple samples at
            presentation or recall.


            But my real problem at the moment is the difference between forward
            and backwards when there is no decay and learning is from multiple
            samples at input. Given that learning takes place on the
            input/forwards sequence and that backward actual recall is just
            reversing the gradient, how can there be a difference?  Also, the
            difference is in learning not in the recall process itself as when I
            look at forward and backward test trials they are also worse when
            learning has been through backward Hebbs.

            But, both forwards and backwards do the same number of updates, so it
            must be the recall that's different, which I've just argued it can't
            be.

            I've just run forwards and backwards with the same random
            seed. The fillers get shuffled in the same way, but the
            recalls are definitely different. That implies that
            selection of particles to update and the whole recall
            process is the same insofar as it must make the same
            number of calls to random. Recall should take the same
            number of calls regardless as this should be determined
            entirely by the number of particles/items.  It also
            implies that the selction of particles to update is the
            same. It is.



            CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK CHECK

            '''

            if not is_presentation:  # no decay if we're using this to generate multiple samples and learn from presentation
                if trial.backwards and params.backwards_output_decay < 1.0:
                    # do decay
                    STM.gradient *= params.backwards_output_decay
              # print(STM.gradient)
                elif not trial.backwards and params.decay < 1.0:
                    STM.gradient *= params.decay  # do decay

        return recall


def print_date():
    print('Run at: ', end=' ')
    print((time.strftime("%H:%M")), end=' ')
    print('on', (time.strftime("%d/%m/%Y")))


################################################################
#                            Result
#
# We have one of these per condition and they're accessed by a dict
# where the key is the condition name taken from the input stimulus file
# e.g. 'Hebb', 'filler'
#
# If we were to parallelise this we'd need a separate results object
# for each iteration and then have a way of
# combining them - maybe overload __add__ Might need to compute the mean
# at the end. The __add__ could
# increment a counter so that adding two results would give the weighted means.
#
#################################################################


class Result(object):
    def __init__(self, length):
        self.name = ''  # condition name e.g. 'Hebb'
        # a list of the responses (same as in the_responses in Trial object)
        self.responses = []
#        self.targets = []
        self.score_mean = 0  # mean score
        self.score_total = 0  # total across all trials * iterations
        self.score_run = 0  # score for this run/iteration. Is this needed?
        self.score_total_run = 0  # total for this run/iteration
        self.count_total = 0  # number of occurrences of this trial type in total
        self.count_run = 0  # number of occurrences of this trial type on this run

        self.gradient = 0.0  # the gradient as computed at the end.

        self.iterations_in_this_result = 0  # using ray we need to know the number
        # of iterations contributing to this Result (which is for one core)
        # to compute the means at the end

        
        # these hold the mean p values for the regression on the gradient.

        self.err = 0.0
        # list of scores by trial ############ DANGEROUS FUDGE ###########
        self.trial_scores = [0] * 50000
        # should derive the number of trials of each sort from the input

        self.trial_no = 0  # the Nth trial of this type. Must be reset between runs
        # total correct by position.
        self.serial_posn_scores_total = [0] * length
        self.serial_posn_scores_mean = [0] * length  # mean correct by position

def add_results_to_first_result(r1, r2):

        if r1.name != r2.name:  # condition name e.g. 'Hebb'
            print('Error in add_results_to_first_result()\
            Trying to add trials of different types', r1.name, r2.name)
            exit(-1)

        r1.score_mean += r2.score_mean  # mean score
        r1.score_total += r2.score_total  # total across all trials * iterations
        r1.score_run += r2.score_run  # score for this run/iteration. Is this needed?
        r1.score_total_run += r2.score_total_run  # total for this run/iteration
        r1.count_total += r2.count_total   # number of occurrences of this trial type in total
        r1.count_run = r2.count_run  # number of occurrences of this trial type on this run
        # r1.gradient = 0.0  # the gradient as computed at the end.

        # these hold the mean p values for the regression on the gradient.

        #self.err = 0.0
        # list of scores by trial ############ DANGEROUS FUDGE ###########
        #self.trial_scores = [0] * 50000
        # should derive the number of trials of each sort from the input

        #self.trial_no = 0  # the Nth trial of this type. Must be reset between runs
        # total correct by position.
        r1.serial_posn_scores_total += r2.serial_posn_scores_total
        r1.serial_posn_scores_mean  += r2.serial_posn_scores_mean # mean correct by position











###############################################
#               Trial
#
# Holds all the information about the trial being presented
# Results are stored in Result
#
###############################################

class Trial(object):
    """Holds all the information about a trial. 
    The results are in Result

    """

    def __init__(self):
        self.memoranda = []  # the list of items to be recalled
        self.memoranda_by_index = []  # the indexes of the memoranda in the vocabulary
        self.trial_number = 0
        self.list_length = 0
        # name for list type: Hebb, cont etc. Use anything you like so long as it has no spaces.
        self.condition = ''
        self.recall = True  # recall trial, or not.
        # if True, and trial is a filler,  shuffle the order of items in this trial
        self.shuffle = False
        self.disable_update = False
        self.backwards = False  # set True if this trial is to be recalled backwards

        # number of repetitions of this trial type (counted from input file)
        self.repetition = 1

    def shuffle_fillers(self):
        """ shuffle the list items
        """

        if self.shuffle:  # general idea is that this is True for fillers
            new_order = random.sample(
                range(len(self.memoranda_by_index)), len(self.memoranda_by_index))
            # reorder the memoranda and indexes according to new_order
            self.memoranda = [y for x, y in sorted(
                zip(new_order, self.memoranda))]
            self.memoranda_by_index = [y for x, y in sorted(
                zip(new_order, self.memoranda_by_index))]


##################################################
#      run_PF()
#
# This is the main controlling fn
#
##################################################
'''To parallelise this we'd need to use a copy of params.results_dict


and then return that. Then we'd need to go through the resulting list
of dicts of results objects and merge results of all instances ofthe
same trial type. The list of trial_types is created when the input
file is read in.

'''


def run_PF(params):
    """This is the main controlling fn
    """

    response_record = []  # a list of the responses for successive trials/
    # used for computing protrusions
    hebb_response_record = []  # as above but for computing hebb error perseverations
    # we don't seem to do anything with it 6-12-18

    # reset the counts of how many trials of each type
    for key, result in params.results_dict.items():
        result.trial_no = 0
    if params.verbose:
        print('\n\n============ START ================\n\n')
    PF = Memory(params)  # create our filter

    # we use a single particle object for our STM
    # new STM particle for every trial

    for trialNo, trial in enumerate(params.trial_list):
        #        print('run_PF trial no: ', trialNo)
        #  PF.reset_particle_distances()
        # use the results object appropriate for this trial type

        this_trial_cond_results = params.results_dict[trial.condition]

        # bit of a fudge for ray to put the right number of iterations in each Results
        this_trial_cond_results.iterations_in_this_result = params.iterations
        
        this_trial_cond_results.count_total += 1
        this_trial_cond_results.count_run += 1
        input_gradient = index_to_gradient(
            trial.memoranda_by_index, params.num_items)
        if params.shuffle_fillers:
            trial.shuffle_fillers()  # this checks first whether the trial is a filler

        '''memoranda_by_index is the length of the actual trial lists, but
        index_to_gradient then returns a gradient params.num_items
        long(i.e. covers all possible items) with the unused(not
        presented) items set to have a gradient/weight of - Inf so
        that they can never be chosen.

        index_to_gradient should probably be a trial member
        function. No. It's also called in run_PF() with the response
        as an arg.
        It's only a couple of lines, so duplicate it

        '''

        ''' This is a mess. we're setting a list_gradient here which we
        then pass to PF.recall_from_STM(tmp, trial) where it gets converted by
        create_forwards_backwards_gradient() if allow_backwards_recall is set.
        Wouldn't it make more sense to set the right gradient up here and keep
        recall_from_STM clean?

        '''

        '''if we're doing updating from input with backwards recall then
        that's exactly the same (at the moment) as doing updating
        after recall, because they both use the same STM noise.


        1. after presentation, update with multiple recalls, possibly with a different STM noise
        2. recall by single sample
        3. update by recall by multiple recalls


        So, if update from multiple recalls, do a single recall first (forwards or backwards) then do
        multiple forwards recalls.
        Possibly have the provision to set a different STM noise when we're calling the multiple
        recalls recall from presenation.



        '''

        gradient = index_to_gradient(
            trial.memoranda_by_index, params.num_items)

        '''Do recall_from_STM. We'll always do a recall first because that
        comes before any updating.  We can then decide how to update.
        If we update by multiple recalls (multiple samples from the
        posterior), this is the same whether we're updating from the
        presentation or recall - apart from the possibility of using
        different levels of STM noise or even decay in the two cases.
        
        Update by adding noise to the input, or response, or doing
        converge all come later.

        NB I'm updating at the end. We could obviously update AND THEN
        RECALL, but there's no provision for this. The main effect of
        this would be to give a double hit of the benefit of
        presentation - one on the STM particles and one from any
        updated particles.

        '''

        # this only applies to recall
        response = PF.recall_from_STM(gradient, trial, is_presentation=False)

        # response is the sequence of positions recalled
        response = response[
            0: trial.list_length]  # ignore anything beyond the length of the list such as words not in the set
        response_gradient = index_to_gradient(response, params.num_items)
        if trial.backwards:  # reverse response if we're doing backward recall
            response = response[::-1]

        if params.verbose:
            print('\n\nrun_PF', trial.condition)
            print('trial: ', trialNo + 1)
            print('run_PF memoranda ', trial.memoranda)
            print('run_PF gradient: ', index_to_gradient(
                trial.memoranda_by_index, params.num_items))
            print(trial.condition, 'memoranda:   ', trial.memoranda)
            print(trial.condition, 'memoranda_by_index: ',
                  trial.memoranda_by_index)
            print(trial.condition, 'response by index:  ', response)
            if trial.memoranda_by_index[3] == response[4] and trial.memoranda_by_index[4] == response[3]:
                print(trial.condition, 'transposition')
            if trialNo > 0 and 'hebb' in trial.condition.lower():
                if hebb_response_record != []:
                    # are there any repetitions of previous errors?
                    for i in range(len(response)):
                        if response[i] != trial.memoranda_by_index[i] and response[i] == (hebb_response_record[-1])[i]:
                            print("error protrusion",
                                  trial.memoranda_by_index[i])
                hebb_response_record.append(copy(response))

        if params.print_responses:
            print(trial.trial_number, ':', trial.condition)
            for item in trial.memoranda_by_index:
                print(params.vocabulary[item], end=' ')
            print()
            for item in response:
                print(params.vocabulary[item], end=' ')
            print('\n')

        response_record.append(copy(response))

        # we disable_update if params.force_update_after_tests is false and
        # the trial condition name contains 'test'
        # We shouldn't need the params.force_update_after_tests bit here
        # as that is already taken care of when setting disable_update in main

        if not trial.disable_update or params.force_update_after_tests:
            # learn from presentation. Updates based on the sequence presented

            '''the confusion I had was that even with converge you could still
            be doing the simple update unless params.prop_copy_presentation
            was set to 1.0

            Although this had the flexibility of allowing you to mix
            them it meant that you had to remember to change two
            similarly named parameters
            '''

            # first deal with what happens on presentation pre 3-10-19
            # this excluded params.posterior_by_multiple_recalls This
            # should be the same whether we're doing forwards or
            # backwards recall as, at this point, all we've got is the
            # input sequence.
            if params.learn_from_presentation_probability > random.random() and params.prop_copy_presentation < 1.0:
                if params.posterior_by_multiple_recalls:
                    # generate new samples by doing lots of recalls
                    #  print('about to call generate_samples_by_recall from presentation in runPF') # DELETE ME
                    # This works on the input gradient so doesn't care whether it's forward or backward recall.
                    PF.generate_samples_by_recall(
                        params.prop_copy_presentation, gradient, trial, is_presentation=True)
                elif params.learn_converge:
                    print('learn_converge procedure no longer exists')
                    print('learn_converge must be set to False')
                    exit(-1)
                else:
                    # just do old-style update from presentation
                    PF.update_some_particles(trial.memoranda_by_index,
                                             params.prop_copy_presentation)

            # now learning from recall
            # NB it doesn't make much sense to learn by multiple samples at both presentation and recall.
            # We might make them differ in noise but that would be all.
            # However, it would make sense to learn from multiple samples at input and update from a single sample
            # plus noise at recall
            if trial.recall and params.learn_from_recall_probability > random.random() and params.prop_copy_recall < 1.0:
                # we no longer allow posterior_by_multiple_recalls in recall
                # It has to be done during presentation
                # generate new samples by doing lots of recalls
                # PF.generate_samples_by_recall(params.prop_copy_recall, gradient, trial, is_presentation=False)
                PF.update_some_particles(response, params.prop_copy_recall)

        recall_score = strict_position_scoring(
            trial, response, this_trial_cond_results.serial_posn_scores_total)
        this_trial_cond_results.score_total += recall_score / trial.list_length
        this_trial_cond_results.trial_scores[this_trial_cond_results.trial_no] += (
            recall_score / trial.list_length)

       

        this_trial_cond_results.trial_no += 1

        this_trial_cond_results.responses.append(
            (response, trial.memoranda_by_index))


        # FOR RAY - do i need to pluf the results back in here?

        # params.results_dict[trial.condition] = this_trial_cond_results
    
   # print('aaaaaaa', trialNo, params.results_dict['hebb'].trial_no, params.results_dict['hebb'].score_total)  # OK here
    return params  


def strict_position_scoring(trial, response, result):
    """
    :param trial:
    :param response:
    :param result:  list accumulating count of correct responses per posn
    :return: number correct in posn
    Works on indexes not items
    """
    '''
    previously I had the results come in reversed for backwards recall but
    '''

    in_position_score = 0

    for i in range(len(trial.memoranda_by_index)):
        if response[i] == trial.memoranda_by_index[i]:
            in_position_score += 1
            result[i] += 1
    return in_position_score


def read_input(filename, params):
    """ reads in .txt file  and returns a trial_list
    """

    '''This should process the input minimally first, just creatng a
    trial with the condition. Then we can run through the trial_list
    afterwards to do things like find out how many different items we
    have. We could add list to a set to do that as we readin.

    '''

    trial_list = []   # list of all trials (ATtrial objects)
    trial_types = []  # different types/conditions
    params.num_trials = 0
    last_row_length = 0

    # need try/except on this open too
    with open(filename, 'r') as f:
        try:
            # fill in the trial objects - one per line
            for line_number, line in enumerate(f):
                row = line.split()  # turn line into list
                if len(row) == 0:
                    break

                one_trial = Trial()  # create trial object
                one_trial.trial_number = line_number
                '''Forgetting that len(row) includes the condition made me add some
                extra stuff to check that items with a -Inf gradient
                were set to be suppresses. I don't think this was
                necessary, but it's belt-and-braces

                '''
                # -1 because the first item is the condition name
                one_trial.list_length = len(row) - 1
                # print('row ', row, 'one_trial.list_length', one_trial.list_length)
                # first item is a label for the trial e.g. "hebb"
                if row[0] not in trial_types:
                    # add it if we haven't seen it before
                    trial_types.append(row[0])

                '''
                We set the shuffle flag for filler trials so they can
                get shuffled randomly for each iteration.
                Condition name only needs to start with filler
                - now it's anywhere
                '''
                one_trial.condition = row[0]
                if 'filler' in one_trial.condition.lower():
                    one_trial.shuffle = True

                if 'test' in one_trial.condition.lower():
                    one_trial.disable_update = True  # if 'test' anywhere in condition name

                if 'back' in one_trial.condition.lower():
                    one_trial.backwards = True  # if 'back' anywhere in condition name

                one_trial.memoranda = row[1:]
                one_trial.the_response = ''
                one_trial.recall = True

                trial_list.append(one_trial)
                params.num_trials += 1
        except:
            print('Error processing input file: ',
                  filename, 'at line number:', line_number + 1)
            sys.exit()

        max_list_len = 0
        min_list_len = 999999999999999999999
        params.vocabulary = []  # complete set of items in all lists
        for tl in trial_list:
            max_list_len = max(len(tl.memoranda), max_list_len)
            min_list_len = min(len(tl.memoranda), min_list_len)
            for it in tl.memoranda:
                if it not in params.vocabulary:
                    params.vocabulary.append(it)
        params.num_items = len(params.vocabulary)
        params.gradient_length = params.num_items
        print("there are", params.num_items, "different items in the input:")

        params.vocabulary.sort()  # easier to read if it's alphabetic
        print("vocabulary", params.vocabulary)
        params.max_list_length = max_list_len
        if max_list_len == min_list_len:
            print("all lists are", max_list_len, "items long")

        else:
            print("max list length = ", max_list_len)
            print("min list length = ", min_list_len)

        '''
        What we're doing here is to take the vocabulary and then use their
        indexes in memoranda_by_index. That also means we can look the
        items up again by their indexes.

        '''
        # maybe move this where it can be done after the param file read in?
        for tl in trial_list:
            tl.memoranda_by_index = []
            for val in tl.memoranda:
                tl.memoranda_by_index.append(params.vocabulary.index(val))
        return trial_list, trial_types


def index_to_gradient(ind, length):
    """takes a list of indexes e.g. [0,2, 3, 1], length = n and returns
    a gradient [1,3,4,2,-Inf, -Inf]. Anything after the first length(
    ind) is assigned a weight of -inf

    Does not check that ind is a valid set of indexes

    """

    try:
        gradient = np.full(length, NEGATIVE_WEIGHT)
        for i in range(len(ind)):
            gradient[ind[i]] = len(ind) - i  # i.e. this is a primacy
            # gradient starting at  len(ind) and ending at zero
        return gradient
    except:
        print("error in index_to_gradient. indexes were: ", ind, "   ", i)


'''This creates both the forwards and backwards gradients for when
we're doing backwards recall and decay at input. First we create a
forwards gradient (i.e. primacy gradient with decresing activation)
using a step size of 1. We use that step size of 1
for num_items_rehearsed, then multiply by decay from then on. That's
like the primacy model notion that there is no input decay while
rehearsal is possible.

The backward gradient is set up from the forwards gradient as though
the steps (after decay) are steps down from the end. i.e. the size of
the steps between items is unchanged but the sign of the steps is
changed. This reverses the gradient such that the step between the
last item and the penultimate item is now the step from the first
item to be recalled to the second. As this hasn't undergone so much
decay as the step between the first two items in forwards recall would
have done, the first item recalled in backwards recall should always
be more accurate than the first item in forwards recall.

This leaves us with a gradient for backwarsd recall that goes -ve so
we fix the gradients to be zero at the lowest to keep them
positive. This is really just to make it easier to see what's going on
during debugging. All that counts is the step size.

NB because if the decay, the effective step size is smaller than when we just
use 1.0 with no decay, therefore it needs less STM noise

'''


def create_forwards_backwards_gradient(params, trial, num_items_rehearsed):
    """ creates gradient both forwards and backwards.
    Needs parameter object, trial object, number of items rehearsed"""

    step_size = 1

    # rem - gradient needs to be as long as the vocabulary not just the list.
    # We should really have params.vocabulary_size = len(params.vocabulary).
    # Activations of vocabulary items not in the list are set to -inf

    forward_gradient = np.full(
        len(params.vocabulary), NEGATIVE_WEIGHT)

    backward_gradient = np.full(
        len(params.vocabulary), NEGATIVE_WEIGHT)

    forward_gradient[0] = 1000.0  # gradient starts from here
    # could be zero, just easier to follow if everything is +ve

    for i in range(len(forward_gradient)-1):
        if params.allow_decay_during_input:
            if i >= num_items_rehearsed - 1:
                forward_gradient[:i+1] *= params.decay

        forward_gradient[i + 1] = forward_gradient[i] - step_size

    backward_gradient[0] = 0.0
    for i in range(1, len(forward_gradient)):
        backward_gradient[i] = forward_gradient[-i] - \
            forward_gradient[-i - 1] + backward_gradient[i-1]
    backward_gradient -= min(backward_gradient)

    # print('backward gradient', backward_gradient)

    forward_gradient -= min(forward_gradient)
    # print('forward gradient', forward_gradient)

    # so far we have a primacy gradient over the items in default order
    # now we reorder them correctly according to the indexes

    f = np.zeros(len(params.vocabulary))
    b = np.zeros(len(params.vocabulary))
    backward_indexes = trial.memoranda_by_index[::-1]
    # print('forward_indexes', trial.memoranda_by_index)
    # print('backward_indexes', backward_indexes)
    for i in range(len(trial.memoranda_by_index)):
        f[trial.memoranda_by_index[i]] = forward_gradient[i]
        b[backward_indexes[i]] = backward_gradient[i]

    f -= min(f)
    b -= min(b)

    '''BEWARE - this normalises the gradient to be in the range list
    length to 1 so that the accuracy is roughly the same as when just
    using a standard gradient with a step of 1.

    '''
    '''
    print('1 f1', f)
    print('1 b1', b)
    '''
    f = f * (len(trial.memoranda_by_index) - 1.0)/max(f) + 1.0
    b = b * (len(trial.memoranda_by_index) - 1.0)/max(b) + 1.0
    '''
    print('2 f', f)
    print('2 b', b)
    print('bi', backward_indexes)
    '''

    # apply echoic boost to most active (first to be recalled) item
    b[np.argmax(b)] += params.echoic_boost
    return (f, b)

# returns a reversed copy of the  gradient.


def reverse_gradient(gradient):
    """ returns a reversed copy of the  gradient."""

    new_gradient = copy(gradient)
    biggest = max(new_gradient)
    smallest = min(new_gradient)
    new_gradient *= -1.0
    new_gradient += biggest + smallest

    return new_gradient


############################################
#            run_everything_once()
#
# does one run through all iterations.
# This was added to be able to do minimisation
# - which we don't bother with any more
# - but we need it for parallelisation
#
############################################

def run_everything_once(params):
    '''
    delete the if part here if you don't have the tqdm library
    '''
    #print('in run_everything_once. iterations:', params.iterations)
    if params.show_progress:
        for iterCount in tqdm(range(params.iterations)):
            params.iteration_count += 1
            if iterCount == 0:
                for key, result in params.results_dict.items():
                    result.trial_scores = [0] * len(result.trial_scores)
                    result.score_mean = 0  # mean score for this condition
            return(run_PF(params))
    else:
        for iterCount in range(params.iterations):
           # print('in run_everything_once: iter=', iterCount)
            params.iteration_count += 1
            if iterCount == 0:
                for key, result in params.results_dict.items():
                    result.trial_scores = [0] * len(result.trial_scores)
                    result.score_mean = 0               
            run_PF(params)
    return(params)

def add_result_to_first_result(r1, r2):

        if r1.name != r2.name:  # condition name e.g. 'Hebb'
            print('Error in add_results_to_first_result()\
            Trying to add trials of different types', r1.name, r2.name)
            exit(-1)
       # print("in add_result_to_first_result", r1.name)
       # print(r1.score_mean, r2.score_mean)

        r1.score_mean += r2.score_mean  # mean score
        r1.score_total += r2.score_total  # total across all trials * iterations
        r1.score_run += r2.score_run  # score for this run/iteration. Is this needed?
        r1.score_total_run += r2.score_total_run  # total for this run/iteration
        r1.count_total += r2.count_total   # number of occurrences of this trial type in total
        r1.iterations_in_this_result += r2.iterations_in_this_result
        #r1.count_run = r2.count_run  # number of occurrences of this trial type on this run
        r1.serial_posn_scores_total = [a + b for a, b in zip(r1.serial_posn_scores_total, r2.serial_posn_scores_total)]
        r1.serial_posn_scores_mean = [a + b for a, b in zip(r1.serial_posn_scores_mean, r2.serial_posn_scores_mean)]
        r1.trial_scores = [a + b for a, b in zip(r1.trial_scores, r2.trial_scores)]


def print_results(final_results_dict):
    for key, result in final_results_dict.items():
        if result.trial_no > 1:
            presentations = [x for x in range(len(result.trial_scores))]
            tmp = [
                x / params.iterations for x in result.trial_scores[0:result.trial_no]]
            gradient, intercept, r_value, p_value, std_err = stats.linregress(
                presentations[0: result.trial_no], tmp)
            result.gradient = gradient
            result.err = p_value
        else:  # no repeats, hence no gradient
            result.gradient = 0.0
            result.err = 0.0

        # In theory you know how long these Score list will be (max of
        # num_trials), but it's asking for trouble to pre-allocate
        # them. So, the only thing to do is to wait until here where
        # we know the size of the lists that run_PF is returning and
        # allocate accordingly.

    # end of iterations loop. now do means and print results

    # print the results sorted alphabetically by condition
    for key in sorted(final_results_dict.keys()):
        result_for_this_condition = final_results_dict[key]

        result_for_this_condition.score_mean = result_for_this_condition.score_total / \
            result_for_this_condition.count_total

        print('\n\n%s: %4.2f, %5.4f' %
              (key, result_for_this_condition.score_mean, result_for_this_condition.gradient))
        print('Position means:', key, ':', end=' ')
        for i in range(len(result_for_this_condition.serial_posn_scores_total)):
            result_for_this_condition.serial_posn_scores_mean[i] = result_for_this_condition.serial_posn_scores_total[i] / \
                result_for_this_condition.count_total
            print('%3.2f ' %
                  (result_for_this_condition.serial_posn_scores_mean[i]), end=' ')
        print('\nRepeats:', key, ':', end=' ')

        for i in range(result_for_this_condition.trial_no):
            print('%3.2f ' %
                  (result_for_this_condition.trial_scores[i] /  result_for_this_condition.iterations_in_this_result), end=' ')
            #            print(result_for_this_condition.trial_scores[i],  result_for_this_condition.iterations_in_this_result, ' = ', end=' ')
    print()
    sys.stdout.flush()

    return 1

# this fn just exists to enable us to parallelise 
# calls to run_everything_once
@ray.remote  # the ray decorator
def call_run_everything_once(params):
    return(run_everything_once(params))



########## Main ########
if __name__ == '__main__':

    using_yaml_parameter_file = False
    trial_list = []
    params = Params()

    if len(sys.argv) < 2 or len(sys.argv) > 3:
        print('Error: Must supply filename as argument and optional parameter file')
        sys.exit()

    print('******************\n')
    print('program:', os.path.abspath(sys.argv[0]))
    print('version:', version)
    print('input file:', os.path.abspath(sys.argv[1]))

    if len(sys.argv) == 2:
        print('Command line:', sys.argv[0], sys.argv[1])
    else:
        print('parameter file:', os.path.abspath(sys.argv[2]))
        print('Command line:', sys.argv[0], sys.argv[1], sys.argv[2])
        using_yaml_parameter_file = True
    print('CWD:', os.getcwd())

    print_date()
    print('\n******************\n')

    # read_input() parses the input file giving us a list of the trials and
    # the_list of the different types/conditions, e.g. Hebb, Filler

    params.trial_list, params.trial_types = read_input(sys.argv[1], params)

    # keep np array printing to 3 decimal places
    np.set_printoptions(
        formatter={'float': lambda x: "{0:0.3f}".format(x)})

    # using the list of trial types  add the type as a key and a result as
    # the value so that we can access arbitrarily named conditions
    for i in params.trial_types:
        params.results_dict[i] = Result(params.max_list_length)
        params.results_dict[i].name = i

    # results = Result(params.max_list_length)  # holds all of the data returned from PFrun

    '''Process the parameter file

    NB this is being done after the stimulus file is read in, so any
    parameter-dependent processing of the trial objects has to be done
    with another pass through them.
    Should do type checking on params

    '''
    print('\n')
    if using_yaml_parameter_file:
        try:
            with open(sys.argv[2], 'r') as f:
                yaml_params = yaml.load(f,  Loader=yaml.SafeLoader)
                # This used to use FullLoader but that's depricated
                # see https://github.com/yaml/pyyaml/wiki/PyYAML-yaml.load(input)-Deprecation
#                yaml_params = yaml.load(f)
            read_yaml_params(yaml_params)
        except:
            print('Error reading or opening parameter file: ', sys.argv[2])
            sys.exit(0)
    else:
        print_params()

    if params.decay <= 0.0 or params.decay > 1.0:
        print('\n\nERROR: Decay must be between 0 and 1 - not:', params.decay)

        '''
        we had a floating point accuracy problem here. I had:
        if params.num_particles * (1.0 - params.prop_copy_presentation) < 1.0:
        but:

        1.0 * (1.0 - .9) = 0.09999999999999998 (should be .1)
        Hence the 0.999999999999998 below
        This isn't a bug in python, it's a floating point gotcha becasue
        you can't represent 0.1 precisely in binary
        https://stackoverflow.com/questions/2925223/floating-point-arithmetic-modulo-operator-on-double-type
        '''
    if params.num_particles * (1.0 - params.prop_copy_presentation) < 0.999999999999998:
        print('WARNING. No particles being updated from presentation. Proportion of updates is:',
              params.num_particles * (1.0 - params.prop_copy_presentation))
        print('increase num_particles or decrease prop_copy_presentation')

    if params.LTM_Luce_noise < 0.03:
        params.LTM_Luce_noise = 0.03
        print('LTM_Luce_noise is too small. Setting it to: ', params.LTM_Luce_noise)

    if params.learn_from_recall_probability > 0.0 and params.posterior_by_multiple_recalls:
        print("WARNING - you are using:")
        print('params.learn_from_recall_probability = ',  params.learn_from_recall_probability,
              ',  params.posterior_by_multiple_recalls = ', params.posterior_by_multiple_recalls)
        print('Only learning from presentation will use posterior_by_multiple_recalls.')
        print(
            'Learning from recall will update by noisy sampling from the recalled sequence')

    if params.learn_from_recall_probability <= 0.0 and params.learn_from_presentation_probability <= 0.0:
        print('WARNING: not doing any learning: learn_from_recall_probability = ', end='')
        print(params.learn_from_recall_probability, ' and learn_from_presentation_probability =',
              params.learn_from_presentation_probability)

    print('\n\n\n')
    if params.particle_setup_length:
        print('Weights initialised to range max_list_length with no noise')
        print('Weights beyond max_list_length set to: ', NEGATIVE_WEIGHT)
        print('particle_setup_length overrides particle_setup_noise')

    elif params.particle_setup_noise < 0.0001 and params.particle_setup_noise > -0.0001:
        print('setting up particles as a random sequence over the entire vocabulary')

    print('\nprop_copy_presentation: ', params.prop_copy_presentation,
          ' N= ', params.prop_copy_presentation * params.num_particles)
    print('prop_copy_recall: ', params.prop_copy_recall, ' N= ',
          params.prop_copy_recall * params.num_particles)

    if not params.strict_position_score:
        print('\nWARNING: no longer supports Levenshtein scoring')
        print('doing strict position scoring\n')

    if params.learn_converge:
        print('\nERROR in parameters: no longer supports the learn_converge option\n')
        exit(-1)

    if params.learn_from_recall_probability < 0.000001:
        print('\nWARNING: not learning from recall so particle_update_noise will have no effect')

    sys.stdout.flush()  # print the params etc now rather than waiting

    '''Now we fix up the backward flag in each trial.  Each trial will
    already have backwards set if it has back in the condition name
    but we need to either remove it if allow_backwards_recall is False
    or set them all to True if params.always_do_backwards_recall is
    True

    If params.allow_backwards_recall is True and
    params.always_do_backwards_recall is False then we just leave
    trial.backwards as it was set in the input file.

    '''

    if params.always_do_backwards_recall and params.allow_backwards_recall:
        for tl in params.trial_list:
            tl.backwards = True  # set all trials to do backward regardless

    if not params.allow_backwards_recall:
        for tl in params.trial_list:
            tl.backwards = False  # never do backward

    if params.force_update_after_tests:
        for tl in params.trial_list:
            tl.disable_update = False

    if params.cores_to_use == 1: # normal single core operation
        print('Using only a single core')
        run_everything_once(params)
        print_results(params.results_dict)
        exit(1)

    # multi-core operation
    remote_list = []
    '''
    now work out how many cores to use
    set params.cores_to_use to 
    0 to use all
    N to use N
    -N to leave N free
    '''
    if params.cores_to_use == 0: # use all available cores
        cpu_count = os.cpu_count()
    elif params.cores_to_use > 0: # use specified number of cores
        cpu_count = min(params.cores_to_use, os.cpu_count())
    elif params.cores_to_use < 0 and os.cpu_count() + params.cores_to_use > 0: # leave specified number of cores free
        cpu_count = os.cpu_count() + params.cores_to_use
    else:
        cpu_count = 1
    params.cores_to_use = cpu_count

    print('This machine has',os.cpu_count(), end="")
    if os.cpu_count() == 1:
        print(' core')
    else:
        print(' cores')

    if params.cores_to_use == 1:
        print('Using 1 core')
    else:
        print('Using', cpu_count, 'cores')

    if params.verbose or params.print_responses:
        print("Warning: can\'t use verbose or print_responses options when using more than one core.")
        print("Setting both to False")
        params.verbose = False
        params.print_responses = False
    if params.show_progress:
        params.show_progress = False # can't have multiple progress indications

    '''
    Now distribute the iterations between the requested cores.
    This deals with cases where the number of iterations is not
    equally divisible by the number of cores. Some processes will
    then do one iteration more than the rest.
    '''
        

    # iterations per cpu, rounded down to nearest int
    iterations_per_cpu = int(params.iterations/cpu_count)

    # the remaining number of iterations to be done
    extra_iterations = params.iterations - (iterations_per_cpu * cpu_count)

    # number of cpus with the basic number of iterations
    basic_cpus = cpu_count - extra_iterations

    # set up the processes with the basic number of iterations
    for cpu in range(basic_cpus):
        params.iterations = iterations_per_cpu
        params.process_number = cpu
        params_copy = deepcopy(params)  # is this necessary?
        remote_list.append(call_run_everything_once.remote(params_copy))
        #print('basic', cpu, params.iterations)

    # now the rest with one more iteration
    for cpu in range(basic_cpus, cpu_count):
        params.iterations = iterations_per_cpu + 1
        params.process_number = cpu
        params_copy = deepcopy(params)  # is this necessary?
        remote_list.append(call_run_everything_once.remote(params_copy))             
        #print('extra', cpu, params.iterations)
  
    ray_output = ray.get(remote_list) # ray.get returns an array of Params


    # this would break if somehow the iterations had different conditions
    # - but should never happen as they are all copies
    
    # outer loop goes through the conditions
    for key, result in ray_output[0].results_dict.items(): # use the first output [0]
          for i in range(cpu_count):  # inner does that condition over all cpus
          #  print(ray_output[i].process_number)
            if i > 0:
                # add_result_to_first_result adds to first arg so no need to return
                add_result_to_first_result(ray_output[0].results_dict[key], ray_output[i].results_dict[key])

    
    print_results(ray_output[0].results_dict)
 #   print('total iterations',ray_output[0].results_dict[key].iterations_in_this_result )
 
        
 #   run_everything_once(params)  # normal operation - no optimisation
 #   print_results(params.results_dict)

    print('\n')
    if _platform == "win32" or _platform == "win64":
        print('\n\nhit return to finish')
        dummy = stdin.readline()  # on windows this stops cmd.exe window from
        # closing until you hit return
